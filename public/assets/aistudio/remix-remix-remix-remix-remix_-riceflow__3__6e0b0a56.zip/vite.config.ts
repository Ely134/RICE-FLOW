import { defineConfig } from 'vite'
import path from 'path'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  server: {
    port: 3000,
    host: true,
  },
  plugins: [
    // The React and Tailwind plugins are both required for Make, even if
    // Tailwind is not being actively used – do not remove them
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: {
      // Alias @ to the src directory
      '@': path.resolve(__dirname, './src'),
    },
  },

  build: {
    rollupOptions: {
      input: {
        main: path.resolve(__dirname, 'index.html'),
        login: path.resolve(__dirname, 'login.html'),
        register: path.resolve(__dirname, 'register.html'),
        reviews: path.resolve(__dirname, 'reviews.html'),
        contact: path.resolve(__dirname, 'contact.html'),
        products: path.resolve(__dirname, 'products.html'),
        productDetails: path.resolve(__dirname, 'product-details.html'),
        cart: path.resolve(__dirname, 'cart.html'),
        checkout: path.resolve(__dirname, 'checkout.html'),
        address: path.resolve(__dirname, 'address.html'),
        reservation: path.resolve(__dirname, 'reservation.html'),
        profile: path.resolve(__dirname, 'profile.html'),
        adminDashboard: path.resolve(__dirname, 'admin/dashboard.html'),
        adminStockReplenishment: path.resolve(__dirname, 'admin/stock-replenishment.html'),
        adminInventoryAnalytics: path.resolve(__dirname, 'admin/inventory-analytics.html'),
        adminReservationAnalytics: path.resolve(__dirname, 'admin/reservation-analytics.html'),
        adminTotalOrders: path.resolve(__dirname, 'admin/total-orders.html'),
        adminTotalSales: path.resolve(__dirname, 'admin/total-sales.html'),
        adminAvailableStock: path.resolve(__dirname, 'admin/available-stock.html'),
        adminTopProduct: path.resolve(__dirname, 'admin/top-product.html'),
        adminOrders: path.resolve(__dirname, 'admin/orders.html'),
        adminProducts: path.resolve(__dirname, 'admin/products.html'),
        adminCustomers: path.resolve(__dirname, 'admin/customers.html'),
        adminInquiries: path.resolve(__dirname, 'admin/inquiries.html'),
        adminStaff: path.resolve(__dirname, 'admin/staff.html'),
        adminReports: path.resolve(__dirname, 'admin/reports.html'),
        adminActivities: path.resolve(__dirname, 'admin/activities.html'),
        adminSettings: path.resolve(__dirname, 'admin/settings.html'),
        adminReservations: path.resolve(__dirname, 'admin/reservations.html'),
        adminCashTurnover: path.resolve(__dirname, 'admin/cash-turnover.html'),
        adminSalesOverview: path.resolve(__dirname, 'admin/sales-overview.html'),
        terms: path.resolve(__dirname, 'terms.html'),
        privacy: path.resolve(__dirname, 'privacy.html'),
        paymentGuide: path.resolve(__dirname, 'payment-guide.html'),
        resetPassword: path.resolve(__dirname, 'reset-password.html'),
        notificationDetails: path.resolve(__dirname, 'notification-details.html'),
        notifications: path.resolve(__dirname, 'notifications.html'),
      }
    }
  },

  // File types to support raw imports. Never add .css, .tsx, or .ts files to this.
  assetsInclude: ['**/*.svg', '**/*.csv'],
})
